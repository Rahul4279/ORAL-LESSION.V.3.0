import gradio as gr
import os
import tempfile
from PIL import Image
import dwani
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Set Dhwani credentials
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

# Language options
language_options = ["english", "kannada", "hindi"]

# Image processing function
def visual_query(image, src_lang, tgt_lang, prompt):
    if image is None:
        return {"error": "Please upload an image."}

    if not prompt.strip():
        return {"error": "Please enter a valid prompt."}

    with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as temp_file:
        image.save(temp_file.name, format="PNG")
        temp_file_path = temp_file.name

    try:
        result = dwani.Vision.caption(
            file_path=temp_file_path,
            query=prompt,
            src_lang=src_lang,
            tgt_lang=tgt_lang
        )
        return result
    except Exception as e:
        return {"error": str(e)}
    finally:
        os.unlink(temp_file_path)

# Gradio interface
iface = gr.Interface(
    fn=visual_query,
    inputs=[
        gr.Image(type="pil", label="🖼️ Upload Image"),
        gr.Dropdown(choices=language_options, label="Source Language", value="english"),
        gr.Dropdown(choices=language_options, label="Target Language", value="kannada"),
        gr.Textbox(label="Prompt", placeholder="e.g., Describe the image")
    ],
    outputs=gr.JSON(label="🧠 API Response"),
    title="🖼️ Dhwani Image Visual Query",
    description="Upload an image and ask a question. The AI will respond in your selected target language."
)

# Launch
if __name__ == "__main__":
    iface.launch()
