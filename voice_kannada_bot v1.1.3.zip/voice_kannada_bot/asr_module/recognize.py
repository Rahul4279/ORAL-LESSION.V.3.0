import os
import dwani
from dotenv import load_dotenv

load_dotenv()

dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

def transcribe_audio(audio_path, language="kannada"):
    try:
        result = dwani.ASR.transcribe(file_path="kannada_sample_2.wav", language="kannada")
        print("ASR Response:", result)
    except Exception as e:
        print(f"Error in ASR module: {e}")
