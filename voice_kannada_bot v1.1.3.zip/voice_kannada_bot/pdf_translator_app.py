import os
import logging
import tempfile
import gradio as gr
from dotenv import load_dotenv
import dwani

# Load environment variables from .env
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Setup Dhwani API keys
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

if not dwani.api_key or not dwani.api_base:
    raise EnvironmentError("❌ DWANI_API_KEY or DWANI_API_BASE_URL not set in .env file")

# Supported languages
language_options = ["english", "kannada", "hindi"]

def process_pdf(pdf_file, page_number, prompt, src_lang, tgt_lang):
    if not pdf_file:
        return {"error": "⚠️ Please upload a PDF file."}, None

    if not prompt.strip():
        return {"error": "⚠️ Prompt cannot be empty."}, None

    try:
        page_number = int(page_number)
        if page_number < 1:
            raise ValueError("Page number must be at least 1.")
    except ValueError:
        return {"error": "⚠️ Invalid page number."}, None

    if src_lang not in language_options or tgt_lang not in language_options:
        return {"error": "⚠️ Invalid language selected."}, None

    try:
        file_path = pdf_file.name if hasattr(pdf_file, 'name') else pdf_file

        # Step 1: Query Dhwani document processor
        result = dwani.Documents.run_doc_query(
            file_path=file_path,
            prompt=prompt,
            page_number=page_number,
            src_lang=src_lang,
            tgt_lang=tgt_lang
        )

        translated_text = result.get("translated_response", "")
        logger.info("Translated Text: %s", translated_text)

        # Step 2: Generate audio
        if not translated_text.strip():
            return {"error": "No translated text received from the server."}, None

        audio_response = dwani.Audio.speech(
            input=translated_text,
            response_format="mp3"
        )

        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_audio:
            temp_audio.write(audio_response)
            audio_path = temp_audio.name

        return {
            "Original Text": result.get("original_text", "N/A"),
            "Response": result.get("response", "N/A"),
            "Processed Page": result.get("processed_page", page_number),
            "Translated Response": translated_text
        }, audio_path

    except dwani.exceptions.DhwaniAPIError as api_err:
        logger.error("Dhwani API error: %s", str(api_err))
        return {"error": f"❌ Dhwani API error: {str(api_err)}"}, None

    except Exception as e:
        logger.exception("Unexpected error occurred")
        return {"error": f"❌ Unexpected error: {str(e)}"}, None

# Gradio UI Setup
with gr.Blocks(title="📄🔊 PDF Translator with AI Voice") as demo:
    gr.Markdown("# 📄🔊 PDF Translator with AI Voice")
    gr.Markdown("Upload a PDF, input a prompt, choose source & target languages, and hear the AI-generated audio output.")

    with gr.Row():
        with gr.Column():
            pdf_input = gr.File(label="📄 Upload PDF", file_types=[".pdf"])
            page_number = gr.Number(label="📄 Page Number", value=1, minimum=1, precision=0)
            prompt = gr.Textbox(label="📝 Prompt", placeholder="e.g., Summarize this page", lines=3)
            src_lang_input = gr.Dropdown(label="🌐 Source Language", choices=language_options, value="english")
            tgt_lang_input = gr.Dropdown(label="🌐 Target Language", choices=language_options, value="kannada")
            submit_btn = gr.Button("🔁 Translate & Speak")

        with gr.Column():
            output_json = gr.JSON(label="🧾 Response")
            audio_output = gr.Audio(label="🔊 AI Spoken Output", type="filepath")

    submit_btn.click(
        fn=process_pdf,
        inputs=[pdf_input, page_number, prompt, src_lang_input, tgt_lang_input],
        outputs=[output_json, audio_output]
    )

if __name__ == "__main__":
    demo.launch()
