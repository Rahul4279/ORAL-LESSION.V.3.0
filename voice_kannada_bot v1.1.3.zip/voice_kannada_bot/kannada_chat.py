import os
import dwani

# Set your API key and base URL
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

# Function to get a Kannada LLM response
def get_kannada_response(prompt):
    try:
        response = dwani.Chat.generate(prompt=prompt, language="kannada")
        return response['response']
    except Exception as e:
        return f"Error: {e}"
