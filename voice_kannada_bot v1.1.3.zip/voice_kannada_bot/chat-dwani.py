import os
import dwani

# Set API key and base URL
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

# Function to generate response from chat model
def get_kannada_response(prompt):
    result = dwani.Chat.generate(prompt=prompt, language="kannada")
    return result["response"]
