import os
import gradio as gr
import dwani
from kannada_chat import get_kannada_response

print("DWANI_API_KEY =", os.getenv("DWANI_API_KEY"))

# Set your API key and base URL
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

def full_pipeline(audio):
    try:
        # Step 1: Transcribe audio
        transcript_result = dwani.ASR.transcribe(file_path=audio, language="kannada")
        transcript = transcript_result.get("text", "")
        
        if not transcript:
            return "Transcription failed", None

        # Step 2: Get response from Kannada LLM
        response = get_kannada_response(transcript)

        # Step 3: Convert response to speech
        tts_audio = dwani.TTS.speak(text=response, language="kannada")

        return response, tts_audio["audio_url"]

    except Exception as e:
        return f"Error: {e}", None

# Gradio UI
with gr.Blocks(title="Kannada Voice Chatbot") as demo:
    gr.Markdown("# 🎙️ Kannada Voice Chatbot")
    gr.Markdown("Speak your question in Kannada. The bot will respond in Kannada.")

    with gr.Row():
        audio_input = gr.Audio(sources=["microphone"], type="filepath", label="Speak Now")

        submit_btn = gr.Button("Ask")
    
    with gr.Row():
        response_text = gr.Textbox(label="Kannada LLM Response")
        audio_output = gr.Audio(label="Spoken Response")

    submit_btn.click(fn=full_pipeline, inputs=[audio_input], outputs=[response_text, audio_output])

demo.launch()
