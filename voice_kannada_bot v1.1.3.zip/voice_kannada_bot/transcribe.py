import gradio as gr
import requests
import os
import dwani
import tempfile
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Supported languages
LANGUAGES = ["malayalam", "tamil", "telugu", "hindi", "kannada"]

# Set API credentials
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

# Function to transcribe and speak
def transcribe_and_speak(audio_file, language):
    # Step 1: Transcribe audio to text
    try:
        result = dwani.ASR.transcribe(file_path=audio_file, language=language)
        transcribed_text = result.get("text", "")
    except Exception as e:
        return {"error": f"Transcription failed: {str(e)}"}, None

    # Step 2: Convert text to speech
    try:
        audio_response = dwani.Audio.speech(input=transcribed_text, response_format="mp3")
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_audio:
            temp_audio.write(audio_response)
            temp_audio_path = temp_audio.name
    except Exception as e:
        return {"error": f"TTS failed: {str(e)}"}, None

    return {"text": transcribed_text}, temp_audio_path

# Gradio UI
with gr.Blocks(title="🎙️ Kannada Voice Chatbot") as demo:
    gr.Markdown("# 🎙️ Kannada Voice Chatbot with AI Speech Reply")

    with gr.Row():
        with gr.Column():
            audio_input = gr.Audio(
                label="Record Your Audio",
                type="filepath",
                sources=["microphone"]  # Only microphone, no upload
            )
            language_input = gr.Dropdown(
                label="Choose Language",
                choices=LANGUAGES,
                value="kannada"
            )
            submit_btn = gr.Button("🔁 Transcribe & Speak")
        
        with gr.Column():
            text_output = gr.JSON(label="📝 Transcription Result")
            voice_output = gr.Audio(label="🔊 AI Spoken Reply", type="filepath")

    submit_btn.click(
        fn=transcribe_and_speak,
        inputs=[audio_input, language_input],
        outputs=[text_output, voice_output]
    )

demo.launch()
