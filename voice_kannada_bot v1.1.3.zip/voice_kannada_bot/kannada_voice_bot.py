import gradio as gr
import tempfile
import os
import dwani

# Set your DWANI API key and base URL (replace with your actual values if known)
dwani.api_key = os.getenv("DWANI_API_KEY")
dwani.api_base = os.getenv("DWANI_API_BASE_URL")

# Step 1: Transcribe Kannada audio to text
def transcribe_audio(audio_path):
    try:
        result = dwani.ASR.transcribe(audio_path, language="Kannada")
        return result["text"]
    except Exception as e:
        return f"[ERROR - Transcription failed]: {str(e)}"

# Step 2: Convert Kannada text to AI voice
def generate_kannada_speech(text):
    try:
        response = dwani.Audio.speech(input=text, response_format="mp3")
        # Save response to a temporary mp3 file
        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as temp_file:
            temp_file.write(response)
            return temp_file.name
    except Exception as e:
        return f"[ERROR - TTS failed]: {str(e)}"

# Step 3: Full pipeline (upload audio -> get text -> convert text to AI voice)
def process_kannada_voice(audio_file):
    text = transcribe_audio(audio_file)
    if text.startswith("[ERROR"):
        return text, None
    
    speech_audio_path = generate_kannada_speech(text)
    if speech_audio_path.startswith("[ERROR"):
        return text, None

    return text, speech_audio_path

# Gradio interface
with gr.Blocks(title="Kannada Voice Chatbot") as demo:
    gr.Markdown("## 🎤 Kannada Voice-to-Text + AI Voice Chatbot")

    with gr.Row():
        with gr.Column():
            voice_input = gr.Audio(sources=["upload"], type="filepath", label="Upload Kannada Audio (.wav)")


        with gr.Column():
            transcription_output = gr.Textbox(label="📝 Transcription (Kannada)")
            ai_voice_output = gr.Audio(label="🔊 AI Generated Kannada Voice", type="filepath")

    voice_input.change(fn=process_kannada_voice, inputs=voice_input, outputs=[transcription_output, ai_voice_output])

# Launch app
demo.launch()
