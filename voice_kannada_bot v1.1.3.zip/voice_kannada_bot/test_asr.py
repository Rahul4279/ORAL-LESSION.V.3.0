from asr_module.recognize import transcribe_audio

result = transcribe_audio("yashaswini.wav", language="kannada")
print("Transcription:", result)
